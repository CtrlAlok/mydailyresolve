import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { UserStats } from "@shared/schema";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from "recharts";
import { Calendar, CheckCircle, XCircle, TrendingUp, Flame, Target } from "lucide-react";

export default function Analytics() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const [selectedPeriod, setSelectedPeriod] = useState("weekly");

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: analytics, isLoading: analyticsLoading } = useQuery<{
    totalEntries: number;
    successCount: number;
    failureCount: number;
    successRate: number;
    dailyData: Array<{ date: string; successes: number; failures: number }>;
  }>({
    queryKey: ["/api/analytics", selectedPeriod],
    retry: (failureCount, error) => {
      if (isUnauthorizedError(error)) return false;
      return failureCount < 3;
    },
  });

  const { data: stats } = useQuery<UserStats>({
    queryKey: ["/api/stats"],
    retry: (failureCount, error) => {
      if (isUnauthorizedError(error)) return false;
      return failureCount < 3;
    },
  });

  if (isLoading || !isAuthenticated) {
    return <div>Loading...</div>;
  }

  const periods = [
    { value: "daily", label: "Daily" },
    { value: "weekly", label: "Weekly" },
    { value: "monthly", label: "Monthly" },
    { value: "yearly", label: "Yearly" },
  ];

  // Prepare data for charts
  const pieData = analytics ? [
    { name: "Successes", value: analytics.successCount, color: "hsl(var(--success))" },
    { name: "Failures", value: analytics.failureCount, color: "hsl(var(--failure))" },
  ] : [];

  const lineData = analytics?.dailyData.map(day => ({
    date: new Date(day.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    successes: day.successes,
    failures: day.failures,
    total: day.successes + day.failures,
  })) || [];

  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h2 className="font-display text-3xl font-bold text-text-dark mb-2">Analytics Dashboard</h2>
        <p className="text-gray-600">Track your progress and identify patterns in your self-control journey</p>
      </div>

      {/* Time Period Selector */}
      <Card className="p-6 mb-6">
        <div className="flex flex-wrap gap-2">
          {periods.map((period) => (
            <Button
              key={period.value}
              variant={selectedPeriod === period.value ? "default" : "outline"}
              onClick={() => setSelectedPeriod(period.value)}
              className={selectedPeriod === period.value ? "bg-primary text-white" : ""}
            >
              {period.label}
            </Button>
          ))}
        </div>
      </Card>

      {/* Analytics Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Progress Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <TrendingUp className="h-5 w-5 mr-2 text-primary" />
              Progress Over Time
            </CardTitle>
          </CardHeader>
          <CardContent>
            {analyticsLoading ? (
              <div className="h-64 flex items-center justify-center">
                <Skeleton className="h-full w-full" />
              </div>
            ) : lineData.length > 0 ? (
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={lineData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Line 
                    type="monotone" 
                    dataKey="successes" 
                    stroke="hsl(var(--success))" 
                    strokeWidth={2}
                    name="Successes"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="failures" 
                    stroke="hsl(var(--failure))" 
                    strokeWidth={2}
                    name="Failures"
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-64 flex items-center justify-center text-gray-500">
                <div className="text-center">
                  <Calendar className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                  <p>No data available for this period</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Success Rate Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Target className="h-5 w-5 mr-2 text-primary" />
              Success Rate
            </CardTitle>
          </CardHeader>
          <CardContent>
            {analyticsLoading ? (
              <div className="h-64 flex items-center justify-center">
                <Skeleton className="h-full w-full" />
              </div>
            ) : analytics && analytics.totalEntries > 0 ? (
              <div className="h-64 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-6xl font-display font-bold text-success mb-4">
                    {Math.round(analytics.successRate)}%
                  </div>
                  <p className="text-gray-600 mb-4">Overall Success Rate</p>
                  <ResponsiveContainer width={200} height={100}>
                    <PieChart>
                      <Pie
                        data={pieData}
                        cx="50%"
                        cy="50%"
                        innerRadius={30}
                        outerRadius={50}
                        dataKey="value"
                      >
                        {pieData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>
            ) : (
              <div className="h-64 flex items-center justify-center text-gray-500">
                <div className="text-center">
                  <Target className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                  <p>No data available</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Detailed Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        <Card className="text-center p-6">
          <Flame className="h-8 w-8 text-orange-500 mx-auto mb-3" />
          <div className="text-2xl font-display font-bold text-text-dark mb-1">
            {stats?.bestStreak || 0}
          </div>
          <div className="text-sm text-gray-600">Longest Streak</div>
        </Card>

        <Card className="text-center p-6">
          <CheckCircle className="h-8 w-8 text-success mx-auto mb-3" />
          <div className="text-2xl font-display font-bold text-text-dark mb-1">
            {stats?.totalResisted || 0}
          </div>
          <div className="text-sm text-gray-600">Total Resisted</div>
        </Card>

        <Card className="text-center p-6">
          <XCircle className="h-8 w-8 text-failure mx-auto mb-3" />
          <div className="text-2xl font-display font-bold text-text-dark mb-1">
            {stats?.totalGaveUp || 0}
          </div>
          <div className="text-sm text-gray-600">Total Gave Up</div>
        </Card>

        <Card className="text-center p-6">
          <Calendar className="h-8 w-8 text-primary mx-auto mb-3" />
          <div className="text-2xl font-display font-bold text-text-dark mb-1">
            {analytics?.totalEntries || 0}
          </div>
          <div className="text-sm text-gray-600">Active Days</div>
        </Card>
      </div>

      {/* Weekly Activity Bar Chart */}
      {lineData.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Calendar className="h-5 w-5 mr-2 text-primary" />
              Daily Activity Breakdown
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={lineData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="successes" fill="hsl(var(--success))" name="Successes" />
                <Bar dataKey="failures" fill="hsl(var(--failure))" name="Failures" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}
    </main>
  );
}
