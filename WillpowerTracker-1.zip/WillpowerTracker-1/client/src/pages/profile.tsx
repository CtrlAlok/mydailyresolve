import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { Camera, Save, CheckCircle, XCircle, Trophy, Medal, Star, Flame, Target } from "lucide-react";

export default function Profile() {
  const { toast } = useToast();
  const { user, isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
  });

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Initialize form data when user data loads
  useEffect(() => {
    if (user) {
      setFormData({
        firstName: user.firstName || "",
        lastName: user.lastName || "",
        email: user.email || "",
      });
    }
  }, [user]);

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/stats"],
    retry: (failureCount, error) => {
      if (isUnauthorizedError(error)) return false;
      return failureCount < 3;
    },
  });

  const updateProfileMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest("PATCH", "/api/user/settings", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      toast({
        title: "Profile Updated",
        description: "Your profile has been updated successfully.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update profile. Please try again.",
        variant: "destructive",
      });
    },
  });

  if (isLoading || !isAuthenticated) {
    return <div>Loading...</div>;
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfileMutation.mutate(formData);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  // Mock achievements for demo purposes
  const achievements = [
    {
      id: 1,
      title: "Week Warrior",
      description: "Maintained streak for 7 days",
      icon: Medal,
      color: "text-yellow-500",
      bgColor: "bg-yellow-50",
      borderColor: "border-yellow-200",
      earned: stats?.currentStreak >= 7,
    },
    {
      id: 2,
      title: "Self-Control Master",
      description: "Reached 100 successful resistances",
      icon: Trophy,
      color: "text-green-500",
      bgColor: "bg-green-50",
      borderColor: "border-green-200",
      earned: stats?.totalResisted >= 100,
    },
    {
      id: 3,
      title: "Consistent Tracker",
      description: "Used the app for 30 days straight",
      icon: Star,
      color: "text-blue-500",
      bgColor: "bg-blue-50",
      borderColor: "border-blue-200",
      earned: stats?.totalResisted + stats?.totalGaveUp >= 30,
    },
  ];

  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h2 className="font-display text-3xl font-bold text-text-dark mb-2">Profile</h2>
        <p className="text-gray-600">Manage your account and view your statistics</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Profile Information */}
        <Card>
          <CardHeader>
            <CardTitle>Profile Information</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="text-center mb-6">
                <Avatar className="w-24 h-24 mx-auto mb-4">
                  <AvatarImage src={user?.profileImageUrl || ""} />
                  <AvatarFallback className="text-2xl">
                    {user?.firstName?.[0]}{user?.lastName?.[0]}
                  </AvatarFallback>
                </Avatar>
                <Button 
                  type="button" 
                  variant="outline" 
                  size="sm"
                  onClick={() => {
                    toast({
                      title: "Coming Soon",
                      description: "Profile picture upload will be available soon.",
                    });
                  }}
                >
                  <Camera className="h-4 w-4 mr-2" />
                  Change Photo
                </Button>
              </div>

              <div className="space-y-4">
                <div>
                  <Label htmlFor="firstName">First Name</Label>
                  <Input
                    id="firstName"
                    value={formData.firstName}
                    onChange={(e) => handleInputChange("firstName", e.target.value)}
                    className="mt-1"
                  />
                </div>
                
                <div>
                  <Label htmlFor="lastName">Last Name</Label>
                  <Input
                    id="lastName"
                    value={formData.lastName}
                    onChange={(e) => handleInputChange("lastName", e.target.value)}
                    className="mt-1"
                  />
                </div>
                
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => handleInputChange("email", e.target.value)}
                    className="mt-1"
                  />
                </div>
                
                <div>
                  <Label htmlFor="memberSince">Member Since</Label>
                  <Input
                    id="memberSince"
                    value={user?.createdAt ? new Date(user.createdAt).toLocaleDateString('en-US', { 
                      year: 'numeric', 
                      month: 'long' 
                    }) : ""}
                    readOnly
                    className="mt-1 bg-gray-50"
                  />
                </div>

                <Button
                  type="submit"
                  disabled={updateProfileMutation.isPending}
                  className="w-full gradient-primary text-white"
                >
                  {updateProfileMutation.isPending ? (
                    "Updating..."
                  ) : (
                    <>
                      <Save className="h-4 w-4 mr-2" />
                      Update Profile
                    </>
                  )}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Profile Stats */}
        <Card>
          <CardHeader>
            <CardTitle>Your Statistics</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="text-center p-4 bg-success bg-opacity-10 rounded-lg">
                {statsLoading ? (
                  <Skeleton className="h-8 w-16 mx-auto mb-1" />
                ) : (
                  <div className="text-2xl font-display font-bold text-success mb-1">
                    {stats?.totalResisted || 0}
                  </div>
                )}
                <div className="text-sm text-gray-600">Times Resisted</div>
              </div>
              
              <div className="text-center p-4 bg-failure bg-opacity-10 rounded-lg">
                {statsLoading ? (
                  <Skeleton className="h-8 w-16 mx-auto mb-1" />
                ) : (
                  <div className="text-2xl font-display font-bold text-failure mb-1">
                    {stats?.totalGaveUp || 0}
                  </div>
                )}
                <div className="text-sm text-gray-600">Times Gave Up</div>
              </div>
              
              <div className="text-center p-4 bg-primary bg-opacity-10 rounded-lg">
                {statsLoading ? (
                  <Skeleton className="h-8 w-16 mx-auto mb-1" />
                ) : (
                  <div className="text-2xl font-display font-bold text-primary mb-1">
                    {stats?.currentStreak || 0}
                  </div>
                )}
                <div className="text-sm text-gray-600">Current Streak</div>
              </div>
              
              <div className="text-center p-4 bg-yellow-500 bg-opacity-10 rounded-lg">
                {statsLoading ? (
                  <Skeleton className="h-8 w-16 mx-auto mb-1" />
                ) : (
                  <div className="text-2xl font-display font-bold text-yellow-600 mb-1">
                    {stats?.bestStreak || 0}
                  </div>
                )}
                <div className="text-sm text-gray-600">Best Streak</div>
              </div>
            </div>

            {/* Achievements */}
            <div className="mt-6">
              <h4 className="font-display text-md font-bold text-text-dark mb-4">Achievements</h4>
              <div className="space-y-3">
                {achievements.map((achievement) => {
                  const Icon = achievement.icon;
                  return (
                    <div
                      key={achievement.id}
                      className={`flex items-center p-3 rounded-lg border ${
                        achievement.earned 
                          ? `${achievement.bgColor} ${achievement.borderColor}` 
                          : "bg-gray-50 border-gray-200"
                      }`}
                    >
                      <Icon className={`text-xl mr-3 ${
                        achievement.earned ? achievement.color : "text-gray-400"
                      }`} />
                      <div>
                        <div className={`font-medium ${
                          achievement.earned ? "text-text-dark" : "text-gray-500"
                        }`}>
                          {achievement.title}
                        </div>
                        <div className="text-sm text-gray-600">
                          {achievement.description}
                        </div>
                      </div>
                      {achievement.earned && (
                        <CheckCircle className="ml-auto h-5 w-5 text-green-500" />
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </main>
  );
}
