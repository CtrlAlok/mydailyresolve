import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import TrackingButtons from "@/components/tracking-buttons";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { UserStats, TrackingEntry } from "@shared/schema";
import { Flame, Calendar, CalendarDays, Trophy, CheckCircle, XCircle, Clock } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export default function Dashboard() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: stats, isLoading: statsLoading } = useQuery<UserStats>({
    queryKey: ["/api/stats"],
    retry: (failureCount, error) => {
      if (isUnauthorizedError(error)) return false;
      return failureCount < 3;
    },
  });

  const { data: recentEntries, isLoading: entriesLoading } = useQuery<TrackingEntry[]>({
    queryKey: ["/api/tracking/recent"],
    retry: (failureCount, error) => {
      if (isUnauthorizedError(error)) return false;
      return failureCount < 3;
    },
  });

  if (isLoading || !isAuthenticated) {
    return <div>Loading...</div>;
  }

  const getSuccessRate = () => {
    if (!stats) return 0;
    const total = stats.totalResisted + stats.totalGaveUp;
    if (total === 0) return 0;
    return Math.round((stats.totalResisted / total) * 100);
  };

  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Current Streak Section */}
      <div className="bg-white rounded-2xl shadow-sm p-8 mb-8 text-center">
        <div className="mb-6">
          <h2 className="font-display text-3xl font-bold text-text-dark mb-2">Current Streak</h2>
          <p className="text-gray-600">Keep building your willpower!</p>
        </div>
        <div className="flex items-center justify-center mb-8">
          <div className="text-center">
            {statsLoading ? (
              <Skeleton className="h-16 w-24 mx-auto mb-2" />
            ) : (
              <div className="text-6xl font-display font-bold text-primary mb-2">
                {stats?.currentStreak || 0}
              </div>
            )}
            <div className="text-lg text-gray-600">Days Strong</div>
          </div>
          <div className="mx-8 text-4xl">🔥</div>
          <div className="text-center">
            {statsLoading ? (
              <Skeleton className="h-8 w-16 mx-auto mb-2" />
            ) : (
              <div className="text-2xl font-display font-bold text-success mb-2">
                {getSuccessRate()}%
              </div>
            )}
            <div className="text-sm text-gray-600">Success Rate</div>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <TrackingButtons />

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 my-8">
        <Card className="text-center p-6">
          <CardContent className="pt-6">
            <Calendar className="h-8 w-8 text-primary mx-auto mb-3" />
            {statsLoading ? (
              <Skeleton className="h-8 w-16 mx-auto mb-1" />
            ) : (
              <div className="text-2xl font-display font-bold text-text-dark mb-1">
                {stats?.currentStreak || 0}
              </div>
            )}
            <div className="text-sm text-gray-600">Current Streak</div>
          </CardContent>
        </Card>

        <Card className="text-center p-6">
          <CardContent className="pt-6">
            <Trophy className="h-8 w-8 text-yellow-500 mx-auto mb-3" />
            {statsLoading ? (
              <Skeleton className="h-8 w-16 mx-auto mb-1" />
            ) : (
              <div className="text-2xl font-display font-bold text-text-dark mb-1">
                {stats?.bestStreak || 0}
              </div>
            )}
            <div className="text-sm text-gray-600">Best Streak</div>
          </CardContent>
        </Card>

        <Card className="text-center p-6">
          <CardContent className="pt-6">
            <Flame className="h-8 w-8 text-orange-500 mx-auto mb-3" />
            {statsLoading ? (
              <Skeleton className="h-8 w-16 mx-auto mb-1" />
            ) : (
              <div className="text-2xl font-display font-bold text-text-dark mb-1">
                {stats?.totalPoints || 0}
              </div>
            )}
            <div className="text-sm text-gray-600">Total Points</div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card className="p-6">
        <h3 className="font-display text-lg font-bold text-text-dark mb-4 flex items-center">
          <Clock className="h-5 w-5 mr-2 text-primary" />
          Recent Activity
        </h3>
        <div className="space-y-3">
          {entriesLoading ? (
            // Loading skeletons
            [...Array(3)].map((_, i) => (
              <div key={i} className="flex items-center justify-between py-3 border-b border-gray-100">
                <div className="flex items-center">
                  <Skeleton className="w-8 h-8 rounded-full mr-3" />
                  <div>
                    <Skeleton className="h-4 w-24 mb-1" />
                    <Skeleton className="h-3 w-16" />
                  </div>
                </div>
                <Skeleton className="h-4 w-8" />
              </div>
            ))
          ) : recentEntries?.length > 0 ? (
            recentEntries.map((entry) => (
              <div key={entry.id} className="flex items-center justify-between py-3 border-b border-gray-100 last:border-0">
                <div className="flex items-center">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center mr-3 ${
                    entry.type === "success" ? "bg-success" : "bg-failure"
                  }`}>
                    {entry.type === "success" ? (
                      <CheckCircle className="h-4 w-4 text-white" />
                    ) : (
                      <XCircle className="h-4 w-4 text-white" />
                    )}
                  </div>
                  <div>
                    <div className="font-medium text-text-dark">
                      {entry.type === "success" ? "I Resisted" : "I Gave Up"}
                    </div>
                    <div className="text-sm text-gray-600">
                      {formatDistanceToNow(new Date(entry.createdAt), { addSuffix: true })}
                    </div>
                  </div>
                </div>
                <div className={`font-medium ${
                  entry.type === "success" ? "text-success" : "text-failure"
                }`}>
                  {entry.type === "success" ? "+10" : "0"}
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-8 text-gray-500">
              <Calendar className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <p>No activity yet. Start tracking your progress!</p>
            </div>
          )}
        </div>
      </Card>
    </main>
  );
}
