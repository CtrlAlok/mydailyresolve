import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Trophy, Crown, Medal, Share2, Link, Users } from "lucide-react";

export default function Leaderboard() {
  const { toast } = useToast();
  const { user, isAuthenticated, isLoading } = useAuth();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: leaderboard, isLoading: leaderboardLoading } = useQuery({
    queryKey: ["/api/leaderboard"],
    retry: (failureCount, error) => {
      if (isUnauthorizedError(error)) return false;
      return failureCount < 3;
    },
  });

  const { data: userRank } = useQuery({
    queryKey: ["/api/leaderboard/rank"],
    retry: (failureCount, error) => {
      if (isUnauthorizedError(error)) return false;
      return failureCount < 3;
    },
  });

  const { data: userStats } = useQuery({
    queryKey: ["/api/stats"],
    retry: (failureCount, error) => {
      if (isUnauthorizedError(error)) return false;
      return failureCount < 3;
    },
  });

  if (isLoading || !isAuthenticated) {
    return <div>Loading...</div>;
  }

  const handleShare = (platform: string) => {
    const text = `I'm rank #${userRank?.rank} on SelfControl with ${userStats?.currentStreak} days streak! Join me in building willpower.`;
    const url = window.location.origin;
    
    switch (platform) {
      case "twitter":
        window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`);
        break;
      case "facebook":
        window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}&quote=${encodeURIComponent(text)}`);
        break;
      case "copy":
        navigator.clipboard.writeText(`${text} ${url}`);
        toast({
          title: "Copied!",
          description: "Link copied to clipboard",
        });
        break;
    }
  };

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1: return <Crown className="h-6 w-6 text-yellow-500" />;
      case 2: return <Medal className="h-6 w-6 text-gray-400" />;
      case 3: return <Medal className="h-6 w-6 text-orange-500" />;
      default: return <span className="text-lg font-bold">#{rank}</span>;
    }
  };

  const getRankBg = (rank: number) => {
    switch (rank) {
      case 1: return "bg-yellow-50 border-yellow-200";
      case 2: return "bg-gray-50 border-gray-200";
      case 3: return "bg-orange-50 border-orange-200";
      default: return "hover:bg-gray-50";
    }
  };

  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h2 className="font-display text-3xl font-bold text-text-dark mb-2">Leaderboard</h2>
        <p className="text-gray-600">See how you rank among the community of self-control champions</p>
      </div>

      {/* Your Rank */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Trophy className="h-5 w-5 mr-2 text-primary" />
            Your Ranking
          </CardTitle>
        </CardHeader>
        <CardContent>
          {userRank && userStats ? (
            <div className="flex items-center justify-between bg-primary bg-opacity-10 rounded-lg p-4">
              <div className="flex items-center">
                <div className="bg-primary text-white rounded-full w-12 h-12 flex items-center justify-center font-bold text-lg mr-4">
                  #{userRank.rank}
                </div>
                <Avatar className="h-12 w-12 mr-4">
                  <AvatarImage src={user?.profileImageUrl || ""} />
                  <AvatarFallback>
                    {user?.firstName?.[0]}{user?.lastName?.[0]}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <div className="font-bold text-text-dark">
                    {user?.firstName} {user?.lastName}
                  </div>
                  <div className="text-sm text-gray-600">
                    Current streak: {userStats.currentStreak} days
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold text-primary">{userStats.totalPoints}</div>
                <div className="text-sm text-gray-600">points</div>
              </div>
            </div>
          ) : (
            <Skeleton className="h-20 w-full" />
          )}
        </CardContent>
      </Card>

      {/* Top Users */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Users className="h-5 w-5 mr-2 text-primary" />
            Top Champions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {leaderboardLoading ? (
              // Loading skeletons
              [...Array(5)].map((_, i) => (
                <div key={i} className="flex items-center justify-between p-4 rounded-lg">
                  <div className="flex items-center">
                    <Skeleton className="w-12 h-12 rounded-full mr-4" />
                    <Skeleton className="w-12 h-12 rounded-full mr-4" />
                    <div>
                      <Skeleton className="h-4 w-24 mb-2" />
                      <Skeleton className="h-3 w-16" />
                    </div>
                  </div>
                  <div className="text-right">
                    <Skeleton className="h-6 w-16 mb-1" />
                    <Skeleton className="h-3 w-12" />
                  </div>
                </div>
              ))
            ) : leaderboard?.length > 0 ? (
              leaderboard.map((entry: any) => (
                <div
                  key={entry.user.id}
                  className={`flex items-center justify-between p-4 rounded-lg border transition-colors ${getRankBg(entry.rank)}`}
                >
                  <div className="flex items-center">
                    <div className="w-12 h-12 flex items-center justify-center mr-4">
                      {getRankIcon(entry.rank)}
                    </div>
                    <Avatar className="h-12 w-12 mr-4">
                      <AvatarImage src={entry.user.profileImageUrl || ""} />
                      <AvatarFallback>
                        {entry.user.anonymousMode 
                          ? "A" 
                          : `${entry.user.firstName?.[0] || ""}${entry.user.lastName?.[0] || ""}`
                        }
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="font-bold text-text-dark">
                        {entry.user.anonymousMode 
                          ? "Anonymous User" 
                          : `${entry.user.firstName || ""} ${entry.user.lastName || ""}`.trim() || "Unknown User"
                        }
                      </div>
                      <div className="text-sm text-gray-600">
                        Streak: {entry.stats.currentStreak} days
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={`text-xl font-bold ${
                      entry.rank === 1 ? "text-yellow-600" : 
                      entry.rank === 2 ? "text-gray-600" : 
                      entry.rank === 3 ? "text-orange-600" : 
                      "text-gray-700"
                    }`}>
                      {entry.stats.totalPoints}
                    </div>
                    <div className="text-sm text-gray-600">points</div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-gray-500">
                <Users className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                <p>No leaderboard data available</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Share Progress */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Share2 className="h-5 w-5 mr-2 text-primary" />
            Share Your Progress
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-3">
            <Button
              onClick={() => handleShare("twitter")}
              className="flex items-center bg-blue-500 hover:bg-blue-600 text-white"
            >
              <Share2 className="h-4 w-4 mr-2" />
              Share on Twitter
            </Button>
            <Button
              onClick={() => handleShare("facebook")}
              className="flex items-center bg-blue-600 hover:bg-blue-700 text-white"
            >
              <Share2 className="h-4 w-4 mr-2" />
              Share on Facebook
            </Button>
            <Button
              onClick={() => handleShare("copy")}
              variant="outline"
              className="flex items-center"
            >
              <Link className="h-4 w-4 mr-2" />
              Copy Link
            </Button>
          </div>
        </CardContent>
      </Card>
    </main>
  );
}
