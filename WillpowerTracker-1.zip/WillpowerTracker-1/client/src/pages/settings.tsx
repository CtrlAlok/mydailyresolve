import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { 
  Bell, 
  Shield, 
  Settings as SettingsIcon, 
  Download, 
  LogOut, 
  Info, 
  Mail, 
  FileText, 
  UserCheck,
  Heart
} from "lucide-react";

export default function Settings() {
  const { toast } = useToast();
  const { user, isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();
  
  const [settings, setSettings] = useState({
    dailyReminders: true,
    celebrations: true,
    weeklyReports: false,
    showInLeaderboard: true,
    anonymousMode: false,
    defaultAnalyticsView: "weekly",
    theme: "light",
  });

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Initialize settings from user data
  useEffect(() => {
    if (user) {
      setSettings({
        dailyReminders: user.dailyReminders ?? true,
        celebrations: user.celebrations ?? true,
        weeklyReports: user.weeklyReports ?? false,
        showInLeaderboard: user.showInLeaderboard ?? true,
        anonymousMode: user.anonymousMode ?? false,
        defaultAnalyticsView: user.defaultAnalyticsView ?? "weekly",
        theme: user.theme ?? "light",
      });
    }
  }, [user]);

  const updateSettingsMutation = useMutation({
    mutationFn: async (newSettings: any) => {
      return await apiRequest("PATCH", "/api/user/settings", newSettings);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      toast({
        title: "Settings Updated",
        description: "Your preferences have been saved.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update settings. Please try again.",
        variant: "destructive",
      });
    },
  });

  if (isLoading || !isAuthenticated) {
    return <div>Loading...</div>;
  }

  const handleSettingChange = (key: string, value: any) => {
    const newSettings = { ...settings, [key]: value };
    setSettings(newSettings);
    updateSettingsMutation.mutate({ [key]: value });
  };

  const handleExportData = () => {
    toast({
      title: "Coming Soon",
      description: "Data export functionality will be available soon.",
    });
  };

  const handleSignOut = () => {
    window.location.href = "/api/logout";
  };

  const handleInfoAction = (action: string) => {
    toast({
      title: "Coming Soon",
      description: `${action} page will be available soon.`,
    });
  };

  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h2 className="font-display text-3xl font-bold text-text-dark mb-2">Settings</h2>
        <p className="text-gray-600">Customize your experience and manage your privacy</p>
      </div>

      <div className="space-y-6">
        {/* Notifications */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Bell className="h-5 w-5 mr-2 text-primary" />
              Notifications
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-base font-medium">Daily Reminders</Label>
                <div className="text-sm text-gray-600">Get reminded to track your progress</div>
              </div>
              <Switch
                checked={settings.dailyReminders}
                onCheckedChange={(checked) => handleSettingChange("dailyReminders", checked)}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-base font-medium">Streak Celebrations</Label>
                <div className="text-sm text-gray-600">Celebrate your milestones</div>
              </div>
              <Switch
                checked={settings.celebrations}
                onCheckedChange={(checked) => handleSettingChange("celebrations", checked)}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-base font-medium">Weekly Reports</Label>
                <div className="text-sm text-gray-600">Summary of your weekly progress</div>
              </div>
              <Switch
                checked={settings.weeklyReports}
                onCheckedChange={(checked) => handleSettingChange("weeklyReports", checked)}
              />
            </div>
          </CardContent>
        </Card>

        {/* Privacy Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Shield className="h-5 w-5 mr-2 text-primary" />
              Privacy & Data
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-base font-medium">Show in Leaderboard</Label>
                <div className="text-sm text-gray-600">Display your progress publicly</div>
              </div>
              <Switch
                checked={settings.showInLeaderboard}
                onCheckedChange={(checked) => handleSettingChange("showInLeaderboard", checked)}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-base font-medium">Anonymous Mode</Label>
                <div className="text-sm text-gray-600">Hide your name from other users</div>
              </div>
              <Switch
                checked={settings.anonymousMode}
                onCheckedChange={(checked) => handleSettingChange("anonymousMode", checked)}
              />
            </div>

            <Separator />
            
            <Button 
              variant="outline" 
              onClick={handleExportData}
              className="w-full justify-start"
            >
              <Download className="h-4 w-4 mr-2" />
              Export My Data
            </Button>
            <p className="text-sm text-gray-600">
              Download all your tracking data and analytics
            </p>
          </CardContent>
        </Card>

        {/* App Preferences */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <SettingsIcon className="h-5 w-5 mr-2 text-primary" />
              App Preferences
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label className="text-base font-medium">Default Analytics View</Label>
              <Select
                value={settings.defaultAnalyticsView}
                onValueChange={(value) => handleSettingChange("defaultAnalyticsView", value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="weekly">Weekly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                  <SelectItem value="yearly">Yearly</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label className="text-base font-medium">Theme</Label>
              <Select
                value={settings.theme}
                onValueChange={(value) => handleSettingChange("theme", value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="light">Light</SelectItem>
                  <SelectItem value="dark">Dark</SelectItem>
                  <SelectItem value="auto">Auto (System)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Support & Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Info className="h-5 w-5 mr-2 text-primary" />
              Support & Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button
              variant="ghost"
              onClick={() => handleInfoAction("About Us")}
              className="w-full justify-start"
            >
              <Heart className="h-4 w-4 mr-2" />
              About SelfControl
            </Button>
            
            <Button
              variant="ghost"
              onClick={() => handleInfoAction("Contact Support")}
              className="w-full justify-start"
            >
              <Mail className="h-4 w-4 mr-2" />
              Contact Support
            </Button>
            
            <Button
              variant="ghost"
              onClick={() => handleInfoAction("Privacy Policy")}
              className="w-full justify-start"
            >
              <UserCheck className="h-4 w-4 mr-2" />
              Privacy Policy
            </Button>
            
            <Button
              variant="ghost"
              onClick={() => handleInfoAction("Terms of Service")}
              className="w-full justify-start"
            >
              <FileText className="h-4 w-4 mr-2" />
              Terms of Service
            </Button>

            <Separator className="my-4" />
            
            <div className="text-center text-sm text-gray-600 mb-4">
              Version 2.1.0
            </div>
            
            <Button
              variant="destructive"
              onClick={handleSignOut}
              className="w-full"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Sign Out
            </Button>
          </CardContent>
        </Card>
      </div>
    </main>
  );
}
