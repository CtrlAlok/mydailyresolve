import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle, BarChart3, Trophy, Users } from "lucide-react";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="font-display text-5xl md:text-7xl font-bold text-text-dark mb-6">
            My<span className="text-primary">Daily</span>Resolve
          </h1>
          <p className="text-xl md:text-2xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Track your willpower, build better habits, and join a community 
            of people committed to self-improvement.
          </p>
          <Button 
            onClick={handleLogin}
            className="gradient-primary text-white text-lg px-8 py-4 rounded-xl shadow-lg hover:shadow-xl transition-all duration-200 transform hover:scale-105"
          >
            Start Your Journey
          </Button>
        </div>

        {/* Features */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          <Card className="text-center p-6 hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <CheckCircle className="h-12 w-12 text-success mx-auto mb-4" />
              <h3 className="font-display text-lg font-bold mb-2">Simple Tracking</h3>
              <p className="text-gray-600">Just two buttons: "I Resisted" or "I Gave Up"</p>
            </CardContent>
          </Card>

          <Card className="text-center p-6 hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <BarChart3 className="h-12 w-12 text-primary mx-auto mb-4" />
              <h3 className="font-display text-lg font-bold mb-2">Detailed Analytics</h3>
              <p className="text-gray-600">Visualize your progress with comprehensive charts</p>
            </CardContent>
          </Card>

          <Card className="text-center p-6 hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <Trophy className="h-12 w-12 text-yellow-500 mx-auto mb-4" />
              <h3 className="font-display text-lg font-bold mb-2">Achievements</h3>
              <p className="text-gray-600">Earn badges and celebrate your milestones</p>
            </CardContent>
          </Card>

          <Card className="text-center p-6 hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <Users className="h-12 w-12 text-purple-500 mx-auto mb-4" />
              <h3 className="font-display text-lg font-bold mb-2">Community</h3>
              <p className="text-gray-600">Compete and share progress with others</p>
            </CardContent>
          </Card>
        </div>

        {/* How it Works */}
        <div className="text-center mb-16">
          <h2 className="font-display text-3xl font-bold text-text-dark mb-8">
            How It Works
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="space-y-4">
              <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto">
                1
              </div>
              <h3 className="font-display text-xl font-bold">Track Daily</h3>
              <p className="text-gray-600">
                Each day, record whether you resisted temptation or gave in
              </p>
            </div>
            <div className="space-y-4">
              <div className="w-16 h-16 bg-success rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto">
                2
              </div>
              <h3 className="font-display text-xl font-bold">Build Streaks</h3>
              <p className="text-gray-600">
                Watch your willpower grow as you build longer success streaks
              </p>
            </div>
            <div className="space-y-4">
              <div className="w-16 h-16 bg-purple-500 rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto">
                3
              </div>
              <h3 className="font-display text-xl font-bold">Improve Together</h3>
              <p className="text-gray-600">
                Share your journey and get motivated by the community
              </p>
            </div>
          </div>
        </div>

        {/* CTA */}
        <div className="text-center bg-white rounded-2xl shadow-lg p-12">
          <h2 className="font-display text-3xl font-bold text-text-dark mb-4">
            Ready to Build Your Willpower?
          </h2>
          <p className="text-gray-600 mb-8 text-lg">
            Join thousands of people improving their self-control every day.
          </p>
          <Button 
            onClick={handleLogin}
            className="gradient-primary text-white text-lg px-8 py-4 rounded-xl shadow-lg hover:shadow-xl transition-all duration-200 transform hover:scale-105"
          >
            Get Started Now
          </Button>
        </div>
      </div>
    </div>
  );
}
