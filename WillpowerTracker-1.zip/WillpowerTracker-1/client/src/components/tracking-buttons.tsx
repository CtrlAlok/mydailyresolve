import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { CheckCircle, XCircle } from "lucide-react";
import { isUnauthorizedError } from "@/lib/authUtils";

interface TrackingButtonsProps {
  onSuccess?: () => void;
  onFailure?: () => void;
}

export default function TrackingButtons({ onSuccess, onFailure }: TrackingButtonsProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const trackingMutation = useMutation({
    mutationFn: async (type: "success" | "failure") => {
      return await apiRequest("POST", "/api/tracking", { type });
    },
    onSuccess: (_, type) => {
      // Invalidate related queries
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tracking/recent"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics"] });
      queryClient.invalidateQueries({ queryKey: ["/api/leaderboard"] });

      if (type === "success") {
        toast({
          title: "Great job! 🎉",
          description: "Your willpower is getting stronger!",
          variant: "default",
        });
        onSuccess?.();
      } else {
        toast({
          title: "Tomorrow is a new opportunity 🌟",
          description: "You got this! Keep going!",
          variant: "default",
        });
        onFailure?.();
      }
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to track your progress. Please try again.",
        variant: "destructive",
      });
    },
  });

  return (
    <div className="bg-white rounded-2xl shadow-sm p-8">
      <h3 className="font-display text-xl font-bold text-text-dark mb-6 text-center">
        How did you do today?
      </h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Success Button */}
        <Button
          onClick={() => trackingMutation.mutate("success")}
          disabled={trackingMutation.isPending}
          className="gradient-success text-white p-8 h-auto rounded-xl shadow-lg transform hover:scale-105 transition-all duration-200 hover:shadow-xl disabled:opacity-50 disabled:transform-none"
        >
          <div className="text-center">
            <CheckCircle className="h-12 w-12 mx-auto mb-4" />
            <h4 className="font-display text-xl font-bold mb-2">I Resisted</h4>
            <p className="text-green-100">You showed great willpower!</p>
          </div>
        </Button>
        
        {/* Failure Button */}
        <Button
          onClick={() => trackingMutation.mutate("failure")}
          disabled={trackingMutation.isPending}
          className="gradient-failure text-white p-8 h-auto rounded-xl shadow-lg transform hover:scale-105 transition-all duration-200 hover:shadow-xl disabled:opacity-50 disabled:transform-none"
        >
          <div className="text-center">
            <XCircle className="h-12 w-12 mx-auto mb-4" />
            <h4 className="font-display text-xl font-bold mb-2">I Gave Up</h4>
            <p className="text-red-100">Tomorrow is a fresh start</p>
          </div>
        </Button>
      </div>
    </div>
  );
}
