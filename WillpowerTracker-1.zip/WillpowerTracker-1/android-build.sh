#!/bin/bash

echo "🚀 Building MyDailyResolve Android APK..."

# Set Java Home
export JAVA_HOME=/nix/store/zmj3m7wrgqf340vqd4v90w8dw371vhjg-openjdk-17.0.7+7/lib/openjdk

# Build the web app
echo "📱 Building web app..."
npm run build

# Sync to Android
echo "🔄 Syncing to Android..."
npx cap sync android

# Build Android APK
echo "🏗️ Building Android APK..."
cd android
./gradlew assembleDebug --no-daemon --console=plain

echo "✅ Build complete! APK location:"
find . -name "*.apk" -type f