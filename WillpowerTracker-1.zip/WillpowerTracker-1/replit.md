# replit.md

## Overview

This is a full-stack TypeScript application called "SelfControl" - a habit tracking and willpower monitoring app. The application uses a modern stack with React frontend, Express backend, and PostgreSQL database with Drizzle ORM. It includes user authentication via Replit Auth, comprehensive analytics, leaderboards, and social features for habit tracking.

**Mobile App Support**: The web application has been enhanced with Capacitor to create native mobile apps for both iOS and Android platforms, maintaining code reuse while providing native app store distribution capabilities.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Framework**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **State Management**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for client-side routing
- **Charts**: Recharts for data visualization

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Authentication**: Replit Auth with OpenID Connect
- **Session Management**: Express sessions with PostgreSQL store
- **API Design**: RESTful API with JSON responses
- **Error Handling**: Centralized error handling middleware

### Database Architecture
- **Database**: PostgreSQL (configured for Neon serverless)
- **ORM**: Drizzle ORM with TypeScript schema definitions
- **Migrations**: Drizzle Kit for database migrations
- **Connection**: Neon serverless driver with connection pooling

## Key Components

### Authentication System
- **Provider**: Replit Auth integration with OpenID Connect
- **Session Storage**: PostgreSQL-based session store using connect-pg-simple
- **Middleware**: Custom authentication middleware for protected routes
- **User Management**: Automatic user creation/updates from auth provider

### Data Models
- **Users**: Profile information, settings, and preferences
- **Tracking Entries**: Daily success/failure records with timestamps
- **User Stats**: Aggregated statistics (streaks, totals, success rates)
- **Sessions**: Authentication session storage

### Frontend Pages
- **Landing**: Unauthenticated welcome page with login
- **Dashboard**: Main tracking interface with quick action buttons
- **Analytics**: Detailed charts and progress visualization
- **Leaderboard**: Community rankings and social features
- **Profile**: User information and achievement displays
- **Settings**: Privacy preferences and account management

### API Endpoints
- **Auth Routes**: `/api/auth/*` for authentication flow
- **Tracking Routes**: `/api/tracking/*` for creating and retrieving entries
- **Analytics Routes**: `/api/analytics/*` for progress data
- **Leaderboard Routes**: `/api/leaderboard/*` for community features
- **User Routes**: `/api/stats/*` for user statistics

## Data Flow

1. **Authentication Flow**: Users authenticate via Replit Auth, sessions stored in PostgreSQL
2. **Tracking Flow**: Users submit success/failure entries → stored in database → stats updated
3. **Analytics Flow**: Frontend requests aggregated data → backend queries database → charts rendered
4. **Real-time Updates**: TanStack Query handles cache invalidation and optimistic updates

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL serverless driver
- **drizzle-orm**: TypeScript ORM for database operations
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Headless UI component primitives
- **wouter**: Lightweight React router

### Mobile App Dependencies
- **@capacitor/core**: Core Capacitor functionality for mobile app bridge
- **@capacitor/cli**: Command-line interface for Capacitor development
- **@capacitor/android**: Android platform support for native app building
- **@capacitor/ios**: iOS platform support for native app building

### Authentication
- **openid-client**: OpenID Connect client for Replit Auth
- **passport**: Authentication middleware
- **express-session**: Session management
- **connect-pg-simple**: PostgreSQL session store

### Development Tools
- **vite**: Fast development server and build tool
- **tsx**: TypeScript execution for development
- **tailwindcss**: Utility-first CSS framework
- **@replit/vite-plugin-***: Replit-specific development plugins

## Deployment Strategy

### Development Environment
- **Hot Reload**: Vite development server with HMR
- **Database**: Neon PostgreSQL with environment-based connection
- **Build Process**: TypeScript compilation with Vite for frontend, esbuild for backend
- **Environment Variables**: DATABASE_URL, SESSION_SECRET, REPL_ID for Replit integration

### Production Build
- **Frontend**: Static assets built to `dist/public`
- **Backend**: Bundled Node.js application with ESM modules
- **Database Migrations**: Drizzle Kit push for schema updates
- **Static Serving**: Express serves built React application

### Mobile App Development
- **Build Process**: Web app builds to `dist/public`, synced to mobile platforms via Capacitor
- **Android Development**: Native Android project in `/android` directory, opens in Android Studio
- **iOS Development**: Native iOS project in `/ios` directory, opens in Xcode (macOS only)
- **Cross-Platform Sync**: `npx cap sync` updates both platforms with latest web build
- **Mobile Testing**: Use device simulators or physical devices through native IDEs

### Key Configuration
- **TypeScript**: Shared configuration for client/server/shared code
- **Path Aliases**: Configured for clean imports (@/, @shared/, @assets/)
- **Database**: PostgreSQL with Drizzle schema-first approach
- **Session Security**: Secure cookies with PostgreSQL persistence