import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
  boolean,
  date,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Session storage table (mandatory for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table (mandatory for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  // Settings
  showInLeaderboard: boolean("show_in_leaderboard").default(true),
  anonymousMode: boolean("anonymous_mode").default(false),
  dailyReminders: boolean("daily_reminders").default(true),
  celebrations: boolean("celebrations").default(true),
  weeklyReports: boolean("weekly_reports").default(false),
  defaultAnalyticsView: varchar("default_analytics_view").default("weekly"),
  theme: varchar("theme").default("light"),
});

// Tracking entries table
export const trackingEntries = pgTable("tracking_entries", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  type: varchar("type").notNull(), // "success" or "failure"
  createdAt: timestamp("created_at").defaultNow(),
  date: date("date").notNull(), // for grouping by day
});

// User statistics table (for caching performance)
export const userStats = pgTable("user_stats", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }).unique(),
  currentStreak: integer("current_streak").default(0),
  bestStreak: integer("best_streak").default(0),
  totalResisted: integer("total_resisted").default(0),
  totalGaveUp: integer("total_gave_up").default(0),
  totalPoints: integer("total_points").default(0),
  lastTrackedDate: date("last_tracked_date"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many, one }) => ({
  trackingEntries: many(trackingEntries),
  stats: one(userStats),
}));

export const trackingEntriesRelations = relations(trackingEntries, ({ one }) => ({
  user: one(users, {
    fields: [trackingEntries.userId],
    references: [users.id],
  }),
}));

export const userStatsRelations = relations(userStats, ({ one }) => ({
  user: one(users, {
    fields: [userStats.userId],
    references: [users.id],
  }),
}));

// Schemas
export const insertUserSchema = createInsertSchema(users).omit({
  createdAt: true,
  updatedAt: true,
});

export const insertTrackingEntrySchema = createInsertSchema(trackingEntries).omit({
  id: true,
  createdAt: true,
});

export const insertUserStatsSchema = createInsertSchema(userStats).omit({
  id: true,
  updatedAt: true,
});

export const updateUserSettingsSchema = createInsertSchema(users).pick({
  showInLeaderboard: true,
  anonymousMode: true,
  dailyReminders: true,
  celebrations: true,
  weeklyReports: true,
  defaultAnalyticsView: true,
  theme: true,
}).partial();

// Types
export type UpsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertTrackingEntry = z.infer<typeof insertTrackingEntrySchema>;
export type TrackingEntry = typeof trackingEntries.$inferSelect;
export type UserStats = typeof userStats.$inferSelect;
export type UpdateUserSettings = z.infer<typeof updateUserSettingsSchema>;
