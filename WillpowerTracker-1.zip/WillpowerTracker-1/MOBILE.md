# SelfControl Mobile App

Your SelfControl habit tracking app is now available as native mobile apps for iOS and Android!

## Quick Start

1. **Build and sync the mobile apps:**
   ```bash
   ./mobile-setup.sh
   ```

2. **Open in native IDEs:**
   ```bash
   # For Android (requires Android Studio)
   npx cap open android
   
   # For iOS (requires Xcode on macOS)
   npx cap open ios
   ```

## Development Workflow

### Making Changes
1. Modify your React components in the `client/src` directory
2. Build and sync: `./mobile-setup.sh`
3. Test in simulators or on devices through the native IDEs

### Key Files
- `capacitor.config.ts` - Mobile app configuration
- `android/` - Android native project  
- `ios/` - iOS native project
- `dist/public/` - Built web assets that power the mobile apps

## App Features on Mobile

✅ **Native App Experience**: Installs like any other mobile app  
✅ **Offline Ready**: Core functionality works without internet  
✅ **Native UI**: Uses device-native navigation and UI elements  
✅ **Push Notifications**: Ready for future notification features  
✅ **App Store Ready**: Can be published to Google Play & Apple App Store  

## Publishing to App Stores

### Android (Google Play)
1. Open project: `npx cap open android`
2. Build release APK in Android Studio
3. Upload to Google Play Console

### iOS (Apple App Store) 
1. Open project: `npx cap open ios` (macOS only)
2. Archive and upload in Xcode
3. Submit through App Store Connect

## Technical Details

- **Web-to-Native Bridge**: Capacitor runs your React app in a native WebView
- **Code Reuse**: 95% of your web code works unchanged on mobile
- **Performance**: Near-native performance for your use case
- **Device APIs**: Ready to add camera, notifications, file system access as needed

Need help with mobile development? The setup is complete and ready to use!