import {
  users,
  trackingEntries,
  userStats,
  type User,
  type UpsertUser,
  type InsertTrackingEntry,
  type TrackingEntry,
  type UserStats,
  type UpdateUserSettings,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql, and, gte, lte, count } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // User settings
  updateUserSettings(userId: string, settings: UpdateUserSettings): Promise<User>;
  
  // Tracking operations
  createTrackingEntry(entry: InsertTrackingEntry): Promise<TrackingEntry>;
  getUserTrackingEntries(userId: string, limit?: number): Promise<TrackingEntry[]>;
  
  // Stats operations
  getUserStats(userId: string): Promise<UserStats | undefined>;
  updateUserStats(userId: string, stats: Partial<UserStats>): Promise<UserStats>;
  
  // Analytics operations
  getUserAnalytics(userId: string, period: string): Promise<{
    totalEntries: number;
    successCount: number;
    failureCount: number;
    successRate: number;
    dailyData: Array<{ date: string; successes: number; failures: number }>;
  }>;
  
  // Leaderboard operations
  getLeaderboard(limit?: number): Promise<Array<{
    user: User;
    stats: UserStats;
    rank: number;
  }>>;
  
  getUserRank(userId: string): Promise<number>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    
    // Initialize user stats if this is a new user
    await db
      .insert(userStats)
      .values({ userId: user.id })
      .onConflictDoNothing();
    
    return user;
  }

  async updateUserSettings(userId: string, settings: UpdateUserSettings): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ ...settings, updatedAt: new Date() })
      .where(eq(users.id, userId))
      .returning();
    
    return user;
  }

  // Tracking operations
  async createTrackingEntry(entry: InsertTrackingEntry): Promise<TrackingEntry> {
    const [trackingEntry] = await db
      .insert(trackingEntries)
      .values(entry)
      .returning();
    
    // Update user stats
    await this.updateUserStatsFromTracking(entry.userId, entry.type);
    
    return trackingEntry;
  }

  async getUserTrackingEntries(userId: string, limit = 10): Promise<TrackingEntry[]> {
    return await db
      .select()
      .from(trackingEntries)
      .where(eq(trackingEntries.userId, userId))
      .orderBy(desc(trackingEntries.createdAt))
      .limit(limit);
  }

  // Stats operations
  async getUserStats(userId: string): Promise<UserStats | undefined> {
    const [stats] = await db
      .select()
      .from(userStats)
      .where(eq(userStats.userId, userId));
    
    return stats;
  }

  async updateUserStats(userId: string, statsData: Partial<UserStats>): Promise<UserStats> {
    const [stats] = await db
      .update(userStats)
      .set({ ...statsData, updatedAt: new Date() })
      .where(eq(userStats.userId, userId))
      .returning();
    
    return stats;
  }

  private async updateUserStatsFromTracking(userId: string, type: string): Promise<void> {
    const stats = await this.getUserStats(userId);
    if (!stats) return;

    const today = new Date().toISOString().split('T')[0];
    
    if (type === "success") {
      const currentStreak = stats.currentStreak || 0;
      const bestStreak = stats.bestStreak || 0;
      const totalPoints = stats.totalPoints || 0;
      const totalResisted = stats.totalResisted || 0;
      
      const newStreak = stats.lastTrackedDate === today ? currentStreak : currentStreak + 1;
      const newBestStreak = Math.max(newStreak, bestStreak);
      const newPoints = totalPoints + 10; // 10 points per success
      
      await this.updateUserStats(userId, {
        currentStreak: newStreak,
        bestStreak: newBestStreak,
        totalResisted: totalResisted + 1,
        totalPoints: newPoints,
        lastTrackedDate: today,
      });
    } else if (type === "failure") {
      const totalGaveUp = stats.totalGaveUp || 0;
      
      await this.updateUserStats(userId, {
        currentStreak: 0, // Reset streak on failure
        totalGaveUp: totalGaveUp + 1,
        lastTrackedDate: today,
      });
    }
  }

  // Analytics operations
  async getUserAnalytics(userId: string, period: string): Promise<{
    totalEntries: number;
    successCount: number;
    failureCount: number;
    successRate: number;
    dailyData: Array<{ date: string; successes: number; failures: number }>;
  }> {
    let daysBack = 7;
    switch (period) {
      case "daily": daysBack = 1; break;
      case "weekly": daysBack = 7; break;
      case "monthly": daysBack = 30; break;
      case "yearly": daysBack = 365; break;
    }

    const startDate = new Date();
    startDate.setDate(startDate.getDate() - daysBack);
    const startDateStr = startDate.toISOString().split('T')[0];

    const entries = await db
      .select()
      .from(trackingEntries)
      .where(
        and(
          eq(trackingEntries.userId, userId),
          gte(trackingEntries.date, startDateStr)
        )
      )
      .orderBy(trackingEntries.date);

    const totalEntries = entries.length;
    const successCount = entries.filter(e => e.type === "success").length;
    const failureCount = entries.filter(e => e.type === "failure").length;
    const successRate = totalEntries > 0 ? (successCount / totalEntries) * 100 : 0;

    // Group by date for daily data
    const dailyData: Array<{ date: string; successes: number; failures: number }> = [];
    const dateMap = new Map<string, { successes: number; failures: number }>();

    entries.forEach(entry => {
      const date = entry.date;
      if (!dateMap.has(date)) {
        dateMap.set(date, { successes: 0, failures: 0 });
      }
      const dayData = dateMap.get(date)!;
      if (entry.type === "success") {
        dayData.successes++;
      } else {
        dayData.failures++;
      }
    });

    dateMap.forEach((data, date) => {
      dailyData.push({ date, ...data });
    });

    return {
      totalEntries,
      successCount,
      failureCount,
      successRate,
      dailyData,
    };
  }

  // Leaderboard operations
  async getLeaderboard(limit = 10): Promise<Array<{
    user: User;
    stats: UserStats;
    rank: number;
  }>> {
    const leaderboardQuery = await db
      .select({
        user: users,
        stats: userStats,
      })
      .from(users)
      .innerJoin(userStats, eq(users.id, userStats.userId))
      .where(eq(users.showInLeaderboard, true))
      .orderBy(desc(userStats.totalPoints), desc(userStats.currentStreak))
      .limit(limit);

    return leaderboardQuery.map((row, index) => ({
      user: row.user,
      stats: row.stats,
      rank: index + 1,
    }));
  }

  async getUserRank(userId: string): Promise<number> {
    const userStats = await this.getUserStats(userId);
    if (!userStats) return 0;

    const [result] = await db
      .select({ count: count() })
      .from(userStats as any)
      .innerJoin(users, eq(users.id, userStats.userId))
      .where(
        and(
          eq(users.showInLeaderboard, true),
          sql`(${userStats.totalPoints} > ${userStats.totalPoints} OR (${userStats.totalPoints} = ${userStats.totalPoints} AND ${userStats.currentStreak} > ${userStats.currentStreak}))`
        )
      );

    return (result?.count || 0) + 1;
  }
}

export const storage = new DatabaseStorage();
