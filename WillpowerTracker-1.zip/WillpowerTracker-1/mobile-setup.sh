#!/bin/bash

# SelfControl Mobile App Setup Script

echo "🏗️  Building web app for mobile..."
npm run build

echo "📱 Syncing to mobile platforms..."
npx cap sync

echo "✅ Mobile apps are ready!"
echo ""
echo "To open the projects in their native IDEs:"
echo "📗 Android: npx cap open android"  
echo "📘 iOS: npx cap open ios"
echo ""
echo "Note: You'll need Android Studio for Android and Xcode (macOS only) for iOS"